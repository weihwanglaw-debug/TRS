import { useState, useRef, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  ArrowLeft, Plus, Edit2, Users, Save, X, Image, Trash2,
  MoreVertical, ExternalLink, Lock, Unlock, FileText, GripVertical,
  Loader2, Download, Upload,
} from "lucide-react";
import type { TournamentEvent, Program, EventDocument } from "@/types/config";
import { getEventStatus } from "@/lib/eventUtils";
import StatusBadge from "@/components/events/StatusBadge";
import ProgramModal from "@/components/admin/ProgramModal";
import SeedingModal from "@/components/admin/SeedingModal";
import { Switch } from "@/components/ui/switch";
import { PageLoader } from "@/components/ui/LoadingSpinner";
import ActionDropdownPortal from "@/components/ui/ActionDropdownPortal";
import { ConfirmDialog } from "@/components/ui/ConfirmDialog";
import { ActionFeedbackDialog, type ActionFeedbackVariant } from "@/components/ui/ActionFeedbackDialog";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  apiGetEvent, apiCreateEvent, apiUpdateEvent, apiDeleteEvent,
  apiUpdateEventRegistrationStatus,
  apiAddProgram, apiUpdateProgram, apiDeleteProgram, apiUpdateProgramStatus,
  apiAddEventDocument, apiUpdateEventDocument, apiDeleteEventDocument,
  apiUploadFile, assetUrl,
  apiPreviewProgramImport, apiConfirmProgramImport,
  type ProgramImportPreviewResponse,
} from "@/lib/api";
import { exportProgramImportTemplate } from "@/lib/exportProgramImportTemplate";

//  Quill rich-text editor
// Install: npm install react-quilljs quill && npm install -D @types/quill
import { useQuill } from "react-quilljs";
import "quill/dist/quill.snow.css";

const MAX_IMAGE_MB = 2;
const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp"];
const MAX_PDF_MB = 8;

function isBlobUrl(url: string) { return url.startsWith("blob:"); }

//  Quill WYSIWYG editor
// Uses react-quilljs (hook wrapper) + Quill Snow theme.
// The Snow theme renders the familiar toolbar with dropdowns for heading,
// font size, alignment, lists, bold, italic, underline, link, etc.
const QUILL_MODULES = {
  toolbar: [
    [{ header: [2, 3, 4, false] }],
    ["bold", "italic", "underline", "strike"],
    [{ list: "ordered" }, { list: "bullet" }],
    [{ align: [] }],
    ["link"],
    ["clean"],
  ],
};

const QUILL_FORMATS = [
  "header",
  "bold",
  "italic",
  "underline",
  "strike",
  "list",
  "align",
  "link",
];

function RichTextEditor({
  value,
  onChange,
  disabled,
}: {
  value: string;
  onChange: (html: string) => void;
  disabled: boolean;
}) {
  const { quill, quillRef } = useQuill({
    modules:  QUILL_MODULES,
    formats:  QUILL_FORMATS,
    readOnly: disabled,
    theme:    "snow",
  });

  // Populate editor when value loads from API
  const initialised = useRef(false);
  useEffect(() => {
    if (!quill) return;
    if (!initialised.current) {
      quill.clipboard.dangerouslyPasteHTML(value || "");
      initialised.current = true;
    }
  }, [quill, value]);

  // Sync disabled state
  useEffect(() => {
    if (!quill) return;
    quill.enable(!disabled);
  }, [quill, disabled]);

  // Fire onChange on every text-change
  useEffect(() => {
    if (!quill) return;
    const handler = () => onChange(quill.root.innerHTML);
    quill.on("text-change", handler);
    return () => { quill.off("text-change", handler); };
  }, [quill, onChange]);

  return (
    <div
      className="quill-wrapper"
      style={{
        opacity: disabled ? 0.7 : 1,
  // Snow theme border uses its own styles via quill.snow.css
      }}
    >
      <div ref={quillRef} style={{ minHeight: 200 }} />
    </div>
  );
}

//  Document manager row
interface DocRow {
  id?: number;       // undefined = not yet saved to backend
  label: string;
  fileUrl: string;
  displayOrder: number;
  uploading?: boolean;
  labelError?: string;
}

export default function EventEdit() {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const isNew = eventId === "new";

  const [event,    setEvent]   = useState<TournamentEvent | null>(null);
  const [loading,  setLoading] = useState(!isNew);
  const [saving,   setSaving]  = useState(false);
  const [feedback, setFeedback] = useState<{
    open: boolean;
    variant: ActionFeedbackVariant;
    title: string;
    description?: string;
  }>({ open: false, variant: "info", title: "" });
  const showError = (title: string, description: string) =>
    setFeedback({ open: true, variant: "error", title, description });

  //  Form state
  const [form, setForm] = useState({
    name: "", description: "", venue: "", venueAddress: "",
    eventStartDate: "", eventEndDate: "", openDate: "", closeDate: "",
    maxParticipants: 100, sponsorInfo: "", bannerUrl: "",
    additionalInfo: "",          // replaces prospectusUrl
    isSports: true, sportType: "Badminton",
    fixtureMode: "internal" as "internal" | "external" | "not_required",
  });

  const [registrationStatusDraft, setRegistrationStatusDraft] = useState<"O" | "PA" | "CL">("O");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const set = <K extends keyof typeof form>(k: K, v: typeof form[K]) =>
    setForm(p => ({ ...p, [k]: v }));

  //  Document rows
  const [docs, setDocs] = useState<DocRow[]>([]);

  //  Gallery / banner
  const [gallery,          setGallery]          = useState<string[]>([]);
  const [galleryError,     setGalleryError]     = useState("");
  const [uploadingGallery, setUploadingGallery] = useState(false);
  const [bannerError,      setBannerError]      = useState("");
  const [uploadingBanner,  setUploadingBanner]  = useState(false);
  const galleryRef = useRef<HTMLInputElement>(null);
  const bannerRef  = useRef<HTMLInputElement>(null);

  //  Program / editing state
  const [editing,          setEditing]          = useState(isNew);
  const [programs,         setPrograms]         = useState<Program[]>([]);
  const [programModalOpen, setProgramModalOpen] = useState(false);
  const [editingProgram,   setEditingProgram]   = useState<Program | null>(null);
  const [seedingOpen,      setSeedingOpen]      = useState(false);
  const [seedingProgramId, setSeedingProgramId] = useState("");
  const [openAction,       setOpenAction]       = useState<{ prog: Program; anchorEl: HTMLElement } | null>(null);
  const [deleteConfirmOpen,setDeleteConfirmOpen]= useState(false);
  const [importProgram,    setImportProgram]    = useState<Program | null>(null);
  const [importFile,       setImportFile]       = useState<File | null>(null);
  const [importPreview,    setImportPreview]    = useState<ProgramImportPreviewResponse | null>(null);
  const [importBusy,       setImportBusy]       = useState(false);
  const [importStatus,     setImportStatus]     = useState<"S" | "W" | "PC">("PC");
  const [importMethod,     setImportMethod]     = useState("Cash");
  const [importReference,  setImportReference]  = useState("");
  const [importNote,       setImportNote]       = useState("");
  const [importError,      setImportError]      = useState("");

  const isBadminton   = form.isSports && form.sportType === "Badminton";
  const showImportPaymentDetails = importStatus === "S";

  //  Load existing event
  useEffect(() => {
    if (isNew) return;
    apiGetEvent(eventId!, { admin: true }).then(r => {
      if (r.error) { showError("Failed to load event", r.error.message); return; }
      const ev = r.data!;
      setEvent(ev);
      setPrograms(ev.programs);
      setRegistrationStatusDraft((ev.registrationStatus ?? "O") as "O" | "PA" | "CL");
      const safeGallery = (ev.galleryUrls || []).filter(u => !isBlobUrl(u));
      if (safeGallery.length !== (ev.galleryUrls || []).length)
        setGalleryError("Some previously selected images were temporary previews and can't be loaded after refresh. Please re-upload them.");
      setGallery(safeGallery);
  // Populate document rows from loaded event
      setDocs((ev.documents || []).map(d => ({
        id: d.id, label: d.label, fileUrl: d.fileUrl, displayOrder: d.displayOrder,
      })));
      setForm({
        name:             ev.name,
        description:      ev.description || "",
        venue:            ev.venue,
        venueAddress:     ev.venueAddress || "",
        eventStartDate:   ev.eventStartDate,
        eventEndDate:     ev.eventEndDate || "",
        openDate:         ev.openDate,
        closeDate:        ev.closeDate,
        maxParticipants:  ev.maxParticipants || 100,
        sponsorInfo:      ev.sponsorInfo || "",
        bannerUrl:        ev.bannerUrl || "",
        additionalInfo:   ev.additionalInfo || "",
        isSports:         ev.isSports ?? true,
        sportType:        ev.sportType === "Badminton" ? "Badminton" : "Non Badminton",
        fixtureMode:      (ev.fixtureMode || "internal") as "internal" | "external" | "not_required",
      });
    }).finally(() => setLoading(false));
  }, [eventId, isNew]);

  //  Gallery upload
  const handleGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setGalleryError("");
    const files = Array.from(e.target.files || []);
    const errs: string[] = [];
    const newUrls: Array<Promise<string | null>> = [];
    files.forEach(f => {
      if (!ALLOWED_TYPES.includes(f.type)) { errs.push(`${f.name}: only JPG, PNG, WEBP allowed`); return; }
      if (f.size > MAX_IMAGE_MB * 1024 * 1024) { errs.push(`${f.name}: exceeds ${MAX_IMAGE_MB}MB limit`); return; }
      newUrls.push(
        apiUploadFile(f, "events/gallery").then(r => {
          if (r.error) { errs.push(`${f.name}: ${r.error.message}`); return null; }
          return r.data;
        }),
      );
    });
    if (errs.length) setGalleryError(errs.join(" - "));
    setUploadingGallery(true);
    void Promise.all(newUrls).then(urls => {
      const good = urls.filter(Boolean) as string[];
      if (errs.length) setGalleryError(errs.join(" - "));
      if (good.length) setGallery(prev => [...prev, ...good]);
    }).finally(() => setUploadingGallery(false));
    if (galleryRef.current) galleryRef.current.value = "";
  };

  const removeGalleryImage = (idx: number) => setGallery(prev => prev.filter((_, i) => i !== idx));

  //  Banner upload
  const handleBannerUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setBannerError("");
    if (file.size > MAX_IMAGE_MB * 1024 * 1024) { setBannerError(`Banner image must be under ${MAX_IMAGE_MB}MB.`); return; }
    setUploadingBanner(true);
    apiUploadFile(file, "events/banner").then(r => {
      if (r.data) set("bannerUrl", r.data);
      else setBannerError(r.error?.message ?? "Upload failed.");
    }).finally(() => { setUploadingBanner(false); if (bannerRef.current) bannerRef.current.value = ""; });
  };

  //  Document handlers
  const addDocRow = () => {
    setDocs(prev => [...prev, { label: "", fileUrl: "", displayOrder: prev.length }]);
  };

  const updateDocRow = (idx: number, patch: Partial<DocRow>) => {
    setDocs(prev => prev.map((d, i) => i === idx ? { ...d, ...patch } : d));
  };

  const removeDocRow = async (idx: number) => {
    const doc = docs[idx];
  // If already saved to backend, delete it
    if (doc.id && !isNew && eventId) {
      await apiDeleteEventDocument(eventId, doc.id);
    }
    setDocs(prev => prev.filter((_, i) => i !== idx));
  };

  const handleDocFileUpload = async (idx: number, file: File) => {
    if (file.size > MAX_PDF_MB * 1024 * 1024) {
      updateDocRow(idx, { labelError: `File exceeds ${MAX_PDF_MB}MB.` });
      return;
    }
    updateDocRow(idx, { uploading: true, labelError: undefined });
    const r = await apiUploadFile(file, "events/documents");
    updateDocRow(idx, { uploading: false });
    if (r.error) { updateDocRow(idx, { labelError: r.error.message }); return; }
    updateDocRow(idx, { fileUrl: r.data! });

  // If saved event exists, persist immediately.
  // Use a ref-safe approach: read current doc state via a one-shot setter to avoid stale closure.
    if (!isNew && eventId) {
      let currentDoc: DocRow | undefined;
      setDocs(prev => {
        currentDoc = prev[idx];
        return prev; // no mutation - reading only
      });
      if (currentDoc?.id) {
        const label = currentDoc.label || file.name.replace(/\.[^.]+$/, "");
        await apiUpdateEventDocument(eventId, currentDoc.id, {
          label, fileUrl: r.data!, displayOrder: currentDoc.displayOrder,
        });
      }
    }
  };

  // Save all unsaved/updated document rows after event is saved
  const saveDocuments = async (savedEventId: string, docsSnapshot: DocRow[]) => {
    for (let i = 0; i < docsSnapshot.length; i++) {
      const doc = docsSnapshot[i];
      if (!doc.fileUrl) continue; // skip rows without a file
      const label = doc.label.trim() || `Document ${i + 1}`;
      if (doc.id) {
        await apiUpdateEventDocument(savedEventId, doc.id, {
          label, fileUrl: doc.fileUrl, displayOrder: i,
        });
      } else {
        const r = await apiAddEventDocument(savedEventId, {
          label, fileUrl: doc.fileUrl, displayOrder: i,
        });
        if (r.data) updateDocRow(i, { id: r.data.id, label });
      }
    }
  };

  //  Validation
  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = "Required";
    if (!form.venue.trim()) e.venue = "Required";
    if (!form.eventStartDate) e.eventStartDate = "Required";
    if (!form.openDate) e.openDate = "Required";
    if (!form.closeDate) e.closeDate = "Required";
    if (form.eventEndDate && form.eventStartDate && form.eventEndDate < form.eventStartDate)
      e.eventEndDate = "Must be on or after start date";
    if (form.closeDate && form.eventStartDate && form.closeDate >= form.eventStartDate)
      e.closeDate = "Must be before event start date";
    if (form.openDate && form.closeDate && form.openDate >= form.closeDate)
      e.openDate = "Must be before close date";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  //  Save
  const handleSave = async () => {
    if (!validate()) return;
    setSaving(true);
    try {
      const payload: Omit<TournamentEvent, "id" | "programs" | "documents"> = {
        ...form,
        galleryUrls: gallery,
      };
      if (isNew) {
        const r = await apiCreateEvent(payload);
        if (r.error) { showError("Event could not be created", r.error.message); return; }
        const newId = r.data!.id;
        for (const prog of programs) {
          const { id: _id, currentParticipants: _cp, participantSeeds: _ps, ...progPayload } = prog;
          void _id; void _cp; void _ps;
          const pr = await apiAddProgram(newId, progPayload);
          if (pr.error) { showError("Event partially saved", `Event created but failed to save program "${prog.name}": ${pr.error.message}`); return; }
        }
        await saveDocuments(newId, docs);
        navigate("/admin/events");
      } else {
        const r = await apiUpdateEvent(eventId!, payload);
        if (r.error) { showError("Event could not be saved", r.error.message); return; }
        await saveDocuments(eventId!, docs);
        let savedEvent = r.data!;
        if (event && registrationStatusDraft !== (event.registrationStatus ?? "O")) {
          const sr = await apiUpdateEventRegistrationStatus(eventId!, registrationStatusDraft);
          if (sr.error) { showError("Registration status could not be saved", sr.error.message); return; }
          savedEvent = sr.data!;
        }
        setEvent(savedEvent);
        setPrograms(savedEvent.programs);
        setRegistrationStatusDraft((savedEvent.registrationStatus ?? "O") as "O" | "PA" | "CL");
        setEditing(false);
        setFeedback({ open: true, variant: "success", title: "Event saved", description: "The event details have been updated." });
      }
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteEvent = async () => {
    if (!eventId || isNew) return;
    setSaving(true);
    const r = await apiDeleteEvent(eventId);
    setSaving(false);
    if (r.error) { showError("Event could not be deleted", r.error.message); return; }
    navigate("/admin/events");
  };

  const resetImportDialog = () => {
    setImportProgram(null);
    setImportFile(null);
    setImportPreview(null);
    setImportBusy(false);
    setImportStatus("PC");
    setImportMethod("Cash");
    setImportReference("");
    setImportNote("");
    setImportError("");
  };

  const handleImportPreview = async () => {
    if (!eventId || !importProgram || !importFile) return;
    setImportBusy(true);
    setImportError("");
    setImportPreview(null);
    try {
      const r = await apiPreviewProgramImport(eventId, importProgram.id, importFile);
      if (r.error) {
        setImportError(r.error.message);
        return;
      }
      setImportPreview(r.data!);
    } catch {
      setImportError("The import template could not be scanned. Please check the file and try again.");
    } finally {
      setImportBusy(false);
    }
  };

  const handleImportConfirm = async () => {
    if (!eventId || !importProgram || !importPreview || !importNote.trim()) return;
    setImportBusy(true);
    setImportError("");
    try {
      const r = await apiConfirmProgramImport(eventId, importProgram.id, {
        importToken: importPreview.importToken,
        paymentStatus: importStatus,
        method: showImportPaymentDetails ? importMethod : undefined,
        paymentReference: showImportPaymentDetails ? importReference || undefined : undefined,
        adminNote: importNote,
      });
      if (r.error) {
        setImportError(r.error.message);
        return;
      }
      const refreshed = await apiGetEvent(eventId, { admin: true });
      if (refreshed.data) {
        setEvent(refreshed.data);
        setPrograms(refreshed.data.programs);
      }
      resetImportDialog();
      setFeedback({
        open: true,
        variant: "success",
        title: "Import saved",
        description: `${r.data!.participantCount} participant(s) saved under registration ${r.data!.registrationId}.`,
      });
    } catch {
      setImportError("The imported registration could not be saved. Please try again.");
    } finally {
      setImportBusy(false);
    }
  };

  const status = event ? getEventStatus(event) : undefined;
  const canChangeRegistrationStatus = !!event && programs.length > 0;
  const panelStyle = {
    border: "1px solid var(--color-table-border)",
    background: "linear-gradient(var(--color-row-hover), var(--color-row-hover)), var(--color-page-bg)",
  };

  if (loading) return <PageLoader label="Loading event..." />;
  if (!isNew && !event && !loading) return (
    <div className="py-20 text-center opacity-40 text-sm">Event not found.</div>
  );

  return (
    <div>
      <ActionFeedbackDialog
        open={feedback.open}
        variant={feedback.variant}
        title={feedback.title}
        description={feedback.description}
        onOpenChange={open => setFeedback(prev => ({ ...prev, open }))}
      />
  {/*  Sticky Header  */}
      <div className="sticky-header px-2 md:px-4" style={panelStyle}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <button onClick={() => navigate("/admin/events")} className="btn-back">
              <ArrowLeft className="h-4 w-4" /> Back
            </button>
            <div>
              <h1 className="font-bold text-2xl">
                {isNew ? "Create New Event" : event?.name || "Event"}
              </h1>
            </div>
          </div>
          <div className="flex gap-3">
            {!isNew && !editing && (
              <>
                <button onClick={() => setDeleteConfirmOpen(true)} disabled={saving}
                  className="btn-outline flex items-center gap-2 px-5 py-2.5 text-sm font-medium"
                  style={{ color: "var(--badge-closed-text)", borderColor: "var(--badge-closed-text)" }}>
                  <Trash2 className="h-4 w-4" /> Delete Event
                </button>
                <button onClick={() => setEditing(true)}
                  className="btn-primary flex items-center gap-2 px-5 py-2.5 text-sm font-semibold">
                  <Edit2 className="h-4 w-4" /> Edit Event
                </button>
              </>
            )}
            {editing && (
              <>
                {!isNew && (
                  <button onClick={() => { setRegistrationStatusDraft((event?.registrationStatus ?? "O") as "O" | "PA" | "CL"); setEditing(false); }}
                    className="btn-outline flex items-center gap-2 px-5 py-2.5 text-sm font-medium">
                    <X className="h-4 w-4" /> Cancel
                  </button>
                )}
                <button onClick={handleSave} disabled={saving}
                  className="btn-primary flex items-center gap-2 px-5 py-2.5 text-sm font-semibold disabled:opacity-50">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                  {saving ? "Saving..." : "Save Event"}
                </button>
              </>
            )}
          </div>
        </div>
      </div>

  {/*  Event Details  */}
      <div className="mb-8 p-8" style={panelStyle}>
        <SectionTitle>Event Details</SectionTitle>
        <div className="grid md:grid-cols-2 gap-6">
          <FF label="Event Name *" error={errors.name}>
            <input className="field-input" value={form.name} onChange={e => set("name", e.target.value)} disabled={!editing} />
          </FF>
          <FF label="Venue Name *" error={errors.venue}>
            <input className="field-input" value={form.venue} onChange={e => set("venue", e.target.value)} disabled={!editing} />
          </FF>
          <div className="md:col-span-2">
            <FF label="Venue Address">
              <input className="field-input" value={form.venueAddress} onChange={e => set("venueAddress", e.target.value)} disabled={!editing} />
            </FF>
          </div>
          <FF label="Event Start Date" error={errors.eventStartDate}>
            <input type="date" className="field-input" value={form.eventStartDate} onChange={e => set("eventStartDate", e.target.value)} disabled={!editing} />
          </FF>
          <FF label="Event End Date" error={errors.eventEndDate}>
            <input type="date" className="field-input" value={form.eventEndDate} onChange={e => set("eventEndDate", e.target.value)} disabled={!editing} />
          </FF>
          <FF label="Registration Open Date" error={errors.openDate}>
            <input type="date" className="field-input" value={form.openDate} onChange={e => set("openDate", e.target.value)} disabled={!editing} />
          </FF>
          <FF label="Registration Close Date" error={errors.closeDate}>
            <input type="date" className="field-input" value={form.closeDate} onChange={e => set("closeDate", e.target.value)} disabled={!editing} />
          </FF>
          <FF label="Max Participants">
            <input type="number" className="field-input" value={form.maxParticipants} onChange={e => set("maxParticipants", +e.target.value)} disabled={!editing} />
          </FF>
          <FF label="Sponsor Information">
            <input className="field-input" value={form.sponsorInfo} onChange={e => set("sponsorInfo", e.target.value)} disabled={!editing} />
          </FF>
          {!isNew && event && status && (
            <div className="md:col-span-2">
              <FF label="Registration Status">
                <div className="flex flex-wrap items-center gap-3">
                  <StatusBadge status={status} />
                  <select
                    className="field-input"
                    value={registrationStatusDraft}
                    disabled={!editing || saving || !canChangeRegistrationStatus}
                    onChange={e => setRegistrationStatusDraft(e.target.value as "O" | "PA" | "CL")}
                    style={{ maxWidth: 260 }}
                    title={canChangeRegistrationStatus ? "Registration status" : "Add at least one program before changing registration status"}
                  >
                    <option value="O">Open registration</option>
                    <option value="PA">Pause registration</option>
                    <option value="CL">Close registration</option>
                  </select>
                </div>
              </FF>
            </div>
          )}
          <div className="md:col-span-2">
            <FF label="Short Description (shown on event header)">
              <textarea className="field-input" rows={2} value={form.description} onChange={e => set("description", e.target.value)} disabled={!editing} />
            </FF>
          </div>
        </div>
      </div>

  {/*  Documents  */}
      <div className="mb-8 p-8" style={panelStyle}>
        <div className="flex items-center justify-between mb-1">
          <SectionTitle>Documents</SectionTitle>
          {editing && (
            <button onClick={addDocRow}
              className="btn-outline flex items-center gap-2 px-4 py-2 text-sm font-medium">
              <Plus className="h-4 w-4" /> Add Document
            </button>
          )}
        </div>
        <p className="text-xs opacity-60 mb-5">
          Upload PDFs for download (prospectus, visa form, hotel form, etc.) - max {MAX_PDF_MB}MB each
        </p>

        {docs.length === 0 && (
          <p className="text-sm opacity-40">{editing ? "No documents yet - click Add Document." : "No documents uploaded."}</p>
        )}

        <div className="space-y-3">
          {docs.map((doc, idx) => (
            <div key={idx} className="flex items-start gap-3 p-3"
              style={{ border: "1px solid var(--color-table-border)", backgroundColor: "var(--color-background-secondary)" }}>
              {editing && <GripVertical className="h-4 w-4 mt-2.5 opacity-30 flex-shrink-0" />}

  {/* Label */}
              <div className="flex-1 min-w-0">
                <input
                  className="field-input mb-1"
                  placeholder="Label, e.g. Prospectus, Visa Application Form..."
                  value={doc.label}
                  disabled={!editing}
                  onChange={e => updateDocRow(idx, { label: e.target.value })}
                />
                {doc.labelError && (
                  <p className="text-xs" style={{ color: "var(--badge-open-text)" }}>{doc.labelError}</p>
                )}
              </div>

  {/* File */}
              <div className="flex-shrink-0">
                {editing ? (
                  <label className={`inline-flex items-center gap-2 btn-outline px-3 py-2 text-xs font-medium cursor-pointer ${doc.uploading ? "opacity-60 pointer-events-none" : ""}`}>
                    {doc.uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FileText className="h-3.5 w-3.5" />}
                    {doc.uploading ? "Uploading..." : doc.fileUrl ? "Replace" : "Choose PDF"}
                    <input
                      type="file" accept="application/pdf,.pdf" className="hidden"
                      disabled={doc.uploading}
                      onChange={e => { const f = e.target.files?.[0]; if (f) handleDocFileUpload(idx, f); e.target.value = ""; }}
                    />
                  </label>
                ) : doc.fileUrl ? (
                  <a href={assetUrl(doc.fileUrl)} target="_blank" rel="noreferrer"
                    className="inline-flex items-center gap-1 text-xs underline"
                    style={{ color: "var(--color-primary)" }}>
                    <FileText className="h-3.5 w-3.5" /> View
                  </a>
                ) : (
                  <span className="text-xs opacity-40">No file</span>
                )}
                {doc.fileUrl && !editing && (
                  <span className="block text-xs opacity-40 mt-0.5 truncate max-w-[160px]">
                    {doc.fileUrl.split("/").pop()}
                  </span>
                )}
              </div>

  {/* Remove */}
              {editing && (
                <button onClick={() => removeDocRow(idx)} className="mt-2 p-1 flex-shrink-0 opacity-50 hover:opacity-100"
                  style={{ color: "var(--badge-closed-text)" }}>
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

  {/*  Additional Information (rich text)  */}
      <div className="mb-8 p-8" style={panelStyle}>
        <SectionTitle>Additional Information</SectionTitle>
        <p className="text-xs opacity-60 mb-4">
          Free-form content shown on the event page - key dates, venue details, important notes, etc.
          Use headings to create sections.
        </p>
        <RichTextEditor
          value={form.additionalInfo}
          onChange={html => set("additionalInfo", html)}
          disabled={!editing}
        />
      </div>

  {/*  Sport / Fixture Settings  */}
      <div className="mb-8 p-8" style={panelStyle}>
        <SectionTitle>Sport &amp; Fixture Settings</SectionTitle>
        <div className="space-y-5">
          <label className="flex items-center gap-3 text-sm cursor-pointer">
            <Switch checked={form.isSports} disabled={!editing}
              onCheckedChange={checked => set("isSports", !!checked)} />
            This is a sports event
          </label>
          {form.isSports && (
            <div className="grid sm:grid-cols-2 gap-6">
              <FF label="Sport Type">
                <select className="field-input" value={form.sportType} disabled={!editing}
                  onChange={e => set("sportType", e.target.value)}>
                  <option>Badminton</option>
                  <option>Non Badminton</option>
                </select>
              </FF>
              <FF label="Fixture Management Mode">
                {editing ? (
                  <div className="flex gap-0">
                    {([
                      { value: "internal",     label: "Internal (Built-in)" },
                      { value: "external",     label: "External System" },
                      { value: "not_required", label: "Not Required" },
                    ] as const).map(opt => (
                      <button key={opt.value} type="button" onClick={() => set("fixtureMode", opt.value)}
                        className="px-4 py-2.5 text-sm font-semibold transition-colors"
                        style={{
                          backgroundColor: form.fixtureMode === opt.value ? "var(--color-primary)" : "transparent",
                          color: form.fixtureMode === opt.value ? "var(--color-hero-text)" : "var(--color-body-text)",
                          border: `1px solid ${form.fixtureMode === opt.value ? "var(--color-primary)" : "var(--color-table-border)"}`,
                        }}>
                        {opt.label}
                      </button>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm font-medium">
                    {form.fixtureMode === "internal" ? "Internal (Built-in)" : form.fixtureMode === "external" ? "External System" : "Not Required"}
                  </p>
                )}
              </FF>
            </div>
          )}
        </div>
      </div>

  {/*  Event Banner  */}
      <div className="mb-8 p-8" style={panelStyle}>
        <SectionTitle>Event Banner</SectionTitle>
        <p className="text-xs opacity-60 mb-4">Hero background on the event page (JPG, PNG, WEBP - max {MAX_IMAGE_MB}MB)</p>
        {editing && (
          <>
            <label className={`inline-flex items-center gap-2 btn-outline px-5 py-2.5 text-sm font-medium cursor-pointer mb-3 ${uploadingBanner ? "opacity-60 pointer-events-none" : ""}`}>
              {uploadingBanner ? <Loader2 className="h-4 w-4 animate-spin" /> : <Image className="h-4 w-4" />}
              {uploadingBanner ? "Uploading..." : form.bannerUrl ? "Replace Banner" : "Upload Banner"}
              <input ref={bannerRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handleBannerUpload} />
            </label>
            {bannerError && <p className="text-xs mb-3" style={{ color: "var(--badge-open-text)" }}>{bannerError}</p>}
          </>
        )}
        {form.bannerUrl ? (
          <div className="relative group" style={{ maxWidth: 640 }}>
            <img src={assetUrl(form.bannerUrl)} alt="Event banner" className="w-full object-cover"
              style={{ maxHeight: 220, border: "1px solid var(--color-table-border)" }} />
            {editing && (
              <button onClick={() => { set("bannerUrl", ""); setBannerError(""); }}
                className="absolute top-2 right-2 p-1.5 opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ backgroundColor: "var(--badge-open-bg)", color: "var(--badge-open-text)" }}>
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        ) : (
          <p className="text-sm opacity-40">No banner uploaded.</p>
        )}
      </div>

  {/*  Gallery  */}
      <div className="mb-8 p-8" style={panelStyle}>
        <SectionTitle>Event Gallery</SectionTitle>
        <p className="text-xs opacity-60 mb-4">Upload multiple images (JPG, PNG, WEBP - max {MAX_IMAGE_MB}MB each)</p>
        {editing && (
          <>
            <label className={`inline-flex items-center gap-2 btn-outline px-5 py-2.5 text-sm font-medium cursor-pointer mb-3 ${uploadingGallery ? "opacity-60 pointer-events-none" : ""}`}>
              {uploadingGallery ? <Loader2 className="h-4 w-4 animate-spin" /> : <Image className="h-4 w-4" />}
              {uploadingGallery ? "Uploading..." : "Upload Images"}
              <input ref={galleryRef} type="file" multiple accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handleGalleryUpload} />
            </label>
            {galleryError && <p className="text-xs mb-3" style={{ color: "var(--badge-open-text)" }}>{galleryError}</p>}
          </>
        )}
        {gallery.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {gallery.map((url, i) => (
              <div key={i} className="relative group aspect-video overflow-hidden"
                style={{ border: "1px solid var(--color-table-border)" }}>
                <img src={assetUrl(url)} alt={`Gallery ${i + 1}`} className="w-full h-full object-cover" />
                {editing && (
                  <button onClick={() => removeGalleryImage(i)}
                    className="absolute top-1 right-1 p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{ backgroundColor: "var(--badge-open-bg)", color: "var(--badge-open-text)" }}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm opacity-40">No images uploaded yet.</p>
        )}
      </div>

  {/*  Programs  */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <SectionTitle>Programs</SectionTitle>
          <button
            onClick={() => { if (!editing) return; setEditingProgram(null); setProgramModalOpen(true); }}
            disabled={!editing}
            className="btn-primary flex items-center gap-2 px-5 py-2.5 text-sm font-semibold disabled:opacity-40 disabled:cursor-not-allowed">
            <Plus className="h-4 w-4" /> Add Program
          </button>
        </div>
        {isNew && programs.length === 0 && (
          <div className="p-5 text-sm opacity-60 text-center" style={{ border: "1px dashed var(--color-table-border)" }}>
            Save the event first, then add programs - or add programs now and save everything together.
          </div>
        )}
        {programs.length > 0 && (
          <>
          <div className="hidden md:block overflow-x-auto" style={{ border: "1px solid var(--color-table-border)" }}>
            <table className="trs-table">
              <thead>
                <tr>
                  <th>Program Name</th><th>Format</th><th>Age</th><th>Gender</th>
                  <th>Fee</th><th>Status</th><th>Min / Max</th><th>Filled</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {programs.map(prog => (
                  <tr key={prog.id}>
                    <td className="font-medium">{prog.name}</td>
                    <td className="text-sm">{prog.type}</td>
                    <td className="text-sm">{prog.minAge}-{prog.maxAge}</td>
                    <td className="text-sm">{prog.gender}</td>
                    <td className="font-semibold text-sm" style={{ color: "var(--color-primary)" }}>
                      {prog.fee > 0 ? `$${prog.fee.toFixed(2)}` : "Free"}
                    </td>
                    <td>
                      <span className="text-xs font-semibold px-2 py-0.5"
                        style={{
                          backgroundColor: prog.status === "CL" ? "var(--badge-closed-bg)" : "var(--badge-open-bg)",
                          color: prog.status === "CL" ? "var(--badge-closed-text)" : "var(--badge-open-text)",
                        }}>
                        {prog.status === "CL" ? "Closed" : "Open"}
                      </span>
                    </td>
                    <td className="text-sm">{prog.minParticipants} / {prog.maxParticipants}</td>
                    <td className="text-sm">
                      <span>{prog.currentParticipants} / {prog.maxParticipants}</span>
                      <div className="h-1 mt-1 w-20" style={{ backgroundColor: "var(--color-table-border)" }}>
                        <div className="h-1 transition-all" style={{
                          width: `${Math.min(100, (prog.currentParticipants / prog.maxParticipants) * 100)}%`,
                          backgroundColor: prog.currentParticipants >= prog.maxParticipants ? "var(--badge-open-text)" : "var(--color-primary)",
                        }} />
                      </div>
                    </td>
                    <td>
                      <div className="relative">
                        <button
                          type="button"
                          onClick={e => { if (!editing) return; setOpenAction(openAction?.prog.id === prog.id ? null : { prog, anchorEl: e.currentTarget }); }}
                          disabled={!editing}
                          className="action-trigger"
                          aria-label={`Open actions for ${prog.name}`}>
                          <MoreVertical className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="md:hidden space-y-3">
            {programs.map(prog => (
              <div key={prog.id} className="p-4" style={{ border: "1px solid var(--color-table-border)" }}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-semibold text-sm truncate">{prog.name}</p>
                    <p className="text-xs opacity-50 mt-0.5">{prog.type} - {prog.gender} - Age {prog.minAge}-{prog.maxAge}</p>
                  </div>
                  <button
                    type="button"
                    onClick={e => { if (!editing) return; setOpenAction(openAction?.prog.id === prog.id ? null : { prog, anchorEl: e.currentTarget }); }}
                    disabled={!editing}
                    className="action-trigger -mr-2"
                    aria-label={`Open actions for ${prog.name}`}
                  >
                    <MoreVertical className="h-4 w-4" />
                  </button>
                </div>
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <span className="text-xs font-semibold px-2 py-0.5"
                    style={{
                      backgroundColor: prog.status === "CL" ? "var(--badge-closed-bg)" : "var(--badge-open-bg)",
                      color: prog.status === "CL" ? "var(--badge-closed-text)" : "var(--badge-open-text)",
                    }}>
                    {prog.status === "CL" ? "Closed" : "Open"}
                  </span>
                  <span className="text-xs opacity-60">Min / Max: {prog.minParticipants} / {prog.maxParticipants}</span>
                </div>
                <div className="mt-4 flex items-end justify-between gap-3">
                  <p className="font-semibold text-sm" style={{ color: "var(--color-primary)" }}>
                    {prog.fee > 0 ? `$${prog.fee.toFixed(2)}` : "Free"}
                  </p>
                  <div className="text-right text-xs opacity-70">
                    Filled
                    <div className="h-1 mt-1 w-24" style={{ backgroundColor: "var(--color-table-border)" }}>
                      <div className="h-1 transition-all" style={{
                        width: `${Math.min(100, (prog.currentParticipants / prog.maxParticipants) * 100)}%`,
                        backgroundColor: prog.currentParticipants >= prog.maxParticipants ? "var(--badge-open-text)" : "var(--color-primary)",
                      }} />
                    </div>
                    <span>{prog.currentParticipants} / {prog.maxParticipants}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          </>
        )}
      </div>

      {openAction && (
        <ActionDropdownPortal open={!!openAction} anchorEl={openAction.anchorEl} onClose={() => setOpenAction(null)}>
          <button onClick={() => { setEditingProgram(openAction.prog); setProgramModalOpen(true); setOpenAction(null); }}>
            <Edit2 className="h-4 w-4" /> Edit Program
          </button>
          {!isNew && event && (
            <button onClick={async () => {
              const prog = openAction.prog;
              setOpenAction(null);
              try {
                await exportProgramImportTemplate(event, prog);
              } catch {
                showError("Import template could not be downloaded", "Please try again. If the issue persists, refresh the page and retry.");
              }
            }}>
              <Download className="h-4 w-4" /> Download Import Template
            </button>
          )}
          {!isNew && event && (
            <button onClick={() => {
              setImportProgram(openAction.prog);
              setImportFile(null);
              setImportPreview(null);
              setImportError("");
              setOpenAction(null);
            }}>
              <Upload className="h-4 w-4" /> Import From Template
            </button>
          )}
          {!isNew && (
            <button onClick={async () => {
              const prog = openAction.prog;
              const newStatus = prog.status === "CL" ? "O" : "CL";
              try {
                const r = await apiUpdateProgramStatus(eventId!, prog.id, newStatus);
                if (r.error) {
                  showError("Program status could not be updated", r.error.message);
                  return;
                }
                if (r.data) setPrograms(prev => prev.map(p => p.id === prog.id ? { ...p, status: newStatus } : p));
              } catch {
                showError("Program status could not be updated", "Please check your connection and try again.");
              } finally {
                setOpenAction(null);
              }
            }}>
              {openAction.prog.status === "CL"
                ? <><Unlock className="h-4 w-4" /> Reopen Program</>
                : <><Lock   className="h-4 w-4" /> Close Program</>}
            </button>
          )}
          {!isNew && (
            <button onClick={() => {
              navigate(`/admin/registrations/participants?eventId=${eventId}&programId=${openAction.prog.id}`);
              setOpenAction(null);
            }}>
              <ExternalLink className="h-4 w-4" /> View Participants
            </button>
          )}
        </ActionDropdownPortal>
      )}

      <Dialog open={!!importProgram} onOpenChange={open => { if (!open && !importBusy) resetImportDialog(); }}>
        <DialogContent
          className="w-[min(96vw,760px)] max-w-3xl max-h-[92vh] overflow-y-auto p-0"
          style={{ backgroundColor: "var(--color-page-bg)", border: "1px solid var(--color-table-border)" }}>
          <DialogHeader className="p-8 pb-0">
            <DialogTitle className="font-bold text-xl">Import Participants</DialogTitle>
          </DialogHeader>

          <div className="p-8 pt-4 space-y-5">
            <div className="grid sm:grid-cols-2 gap-3 text-sm">
              <div className="p-3" style={{ border: "1px solid var(--color-table-border)" }}>
                <p className="text-xs font-semibold opacity-50">Event</p>
                <p className="font-semibold">{event?.name}</p>
              </div>
              <div className="p-3" style={{ border: "1px solid var(--color-table-border)" }}>
                <p className="text-xs font-semibold opacity-50">Program</p>
                <p className="font-semibold">{importProgram?.name}</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold mb-2 opacity-70">Import Template *</label>
              <input
                type="file"
                accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                className="field-input"
                disabled={importBusy}
                onChange={e => {
                  setImportFile(e.target.files?.[0] ?? null);
                  setImportPreview(null);
                  setImportError("");
                }}
              />
            </div>

            {!importPreview && (
              <div className="p-3 text-sm" style={{ backgroundColor: "var(--badge-soon-bg)", color: "var(--badge-soon-text)" }}>
                Upload the completed Excel template. The system will scan all rows first and show every validation issue together before anything is saved.
              </div>
            )}

            {importError && (
              <div className="p-3 text-sm" style={{ backgroundColor: "var(--badge-closed-bg)", color: "var(--badge-closed-text)" }}>
                {importError}
              </div>
            )}

            {importPreview && (
              <div className="space-y-4">
                <div className="grid sm:grid-cols-3 gap-3 text-sm">
                  <div className="p-3" style={{ border: "1px solid var(--color-table-border)" }}>
                    <p className="text-xs font-semibold opacity-50">Entries</p>
                    <p className="text-lg font-bold">{importPreview.entries.length}</p>
                  </div>
                  <div className="p-3" style={{ border: "1px solid var(--color-table-border)" }}>
                    <p className="text-xs font-semibold opacity-50">Participants</p>
                    <p className="text-lg font-bold">{importPreview.participantCount}</p>
                  </div>
                  <div className="p-3" style={{ border: "1px solid var(--color-table-border)" }}>
                    <p className="text-xs font-semibold opacity-50">Result</p>
                    <p className="text-lg font-bold" style={{ color: importPreview.valid ? "var(--badge-paid-text)" : "var(--badge-closed-text)" }}>
                      {importPreview.valid ? "Ready" : "Needs Fix"}
                    </p>
                  </div>
                </div>

                {importPreview.entries.length > 0 && (
                  <div className="max-h-40 overflow-y-auto" style={{ border: "1px solid var(--color-table-border)" }}>
                    <table className="trs-table">
                      <thead>
                        <tr><th>Entry No.</th><th>Players</th><th>Names</th></tr>
                      </thead>
                      <tbody>
                        {importPreview.entries.map(entry => (
                          <tr key={entry.entryNo}>
                            <td className="text-sm">{entry.entryNo}</td>
                            <td className="text-sm">{entry.participantCount}</td>
                            <td className="text-sm">{entry.names || "-"}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {importPreview.errors.length > 0 && (
                  <IssueList title="Validation Errors" issues={importPreview.errors} tone="error" />
                )}
                {importPreview.warnings.length > 0 && (
                  <IssueList title="Warnings" issues={importPreview.warnings} tone="warning" />
                )}

                {importPreview.valid && (
                  <div className="space-y-4 pt-2">
                    <div>
                      <label className="block text-xs font-semibold mb-2 opacity-70">Payment Status *</label>
                      <div className="grid grid-cols-3 gap-2">
                        {([
                          { value: "S",  label: "Paid",               sub: "Collected now" },
                          { value: "W",  label: "Waived",             sub: "Fee waived" },
                          { value: "PC", label: "Pending Collection", sub: "Will pay later" },
                        ] as const).map(opt => (
                          <button
                            key={opt.value}
                            type="button"
                            onClick={() => setImportStatus(opt.value)}
                            className="p-3 text-left text-xs transition-all"
                            style={{
                              border: `2px solid ${importStatus === opt.value ? "var(--color-primary)" : "var(--color-table-border)"}`,
                              backgroundColor: importStatus === opt.value ? "var(--color-row-hover)" : "transparent",
                            }}>
                            <p className="font-semibold">{opt.label}</p>
                            <p className="opacity-50 mt-0.5">{opt.sub}</p>
                          </button>
                        ))}
                      </div>
                    </div>

                    {showImportPaymentDetails && (
                      <div className="grid sm:grid-cols-2 gap-4">
                        <FF label="Payment Method">
                          <select className="field-input" value={importMethod} onChange={e => setImportMethod(e.target.value)}>
                            <option value="Cash">Cash</option>
                            <option value="BankTransfer">Bank Transfer</option>
                            <option value="PayNow">PayNow</option>
                            <option value="Others">Others</option>
                          </select>
                        </FF>
                        <FF label="Payment Reference (optional)">
                          <input className="field-input" value={importReference}
                            onChange={e => setImportReference(e.target.value)}
                            placeholder="e.g. PayNow ref, receipt number" />
                        </FF>
                      </div>
                    )}

                    <FF label="Admin Remark *">
                      <textarea className="field-input" rows={2} value={importNote}
                        onChange={e => setImportNote(e.target.value)}
                        placeholder="e.g. Bulk import approved by admin" />
                    </FF>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="p-8 pt-0 flex flex-wrap gap-3 justify-end">
            {!importError && !(importPreview && !importPreview.valid) && (
              <button type="button" disabled={importBusy} onClick={resetImportDialog}
                className="btn-outline px-5 py-2.5 text-sm font-medium disabled:opacity-40">
                Cancel
              </button>
            )}
            {!importPreview && !importError && (
              <button type="button" disabled={!importFile || importBusy} onClick={handleImportPreview}
                className="btn-primary px-5 py-2.5 text-sm font-semibold disabled:opacity-40">
                {importBusy ? <><Loader2 className="h-4 w-4 animate-spin" /> Scanning...</> : "Scan Template"}
              </button>
            )}
            {((importPreview && !importPreview.valid) || importError) && (
              <button type="button" disabled={importBusy} onClick={resetImportDialog}
                className="btn-primary px-5 py-2.5 text-sm font-semibold disabled:opacity-40">
                OK
              </button>
            )}
            {importPreview?.valid && (
              <button type="button" disabled={!importNote.trim() || importBusy} onClick={handleImportConfirm}
                className="btn-primary px-5 py-2.5 text-sm font-semibold disabled:opacity-40">
                {importBusy ? <><Loader2 className="h-4 w-4 animate-spin" /> Saving...</> : "Save Import"}
              </button>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <ProgramModal
        open={programModalOpen}
        onClose={() => { setProgramModalOpen(false); setEditingProgram(null); }}
        onSave={async (savedProgram: Program) => {
          const wasEditingProgram = !!editingProgram;
          if (!isNew && eventId && eventId !== "new") {
            if (editingProgram) {
              const r = await apiUpdateProgram(eventId, savedProgram.id, savedProgram);
              if (r.error) return r.error.message;
              if (r.data) setPrograms(prev => prev.map(p => p.id === r.data!.id ? r.data! : p));
            } else {
              const { id: _id, currentParticipants: _cp, participantSeeds: _ps, ...payload } = savedProgram;
              void _id; void _cp; void _ps;
              const r = await apiAddProgram(eventId, payload);
              if (r.error) return r.error.message;
              if (r.data) setPrograms(prev => [...prev, r.data!]);
            }
          } else {
            if (editingProgram) {
              setPrograms(prev => prev.map(p => p.id === savedProgram.id ? savedProgram : p));
            } else {
              setPrograms(prev => [...prev, {
                ...savedProgram,
                id: `prog-temp-${Date.now().toString(36)}`,
                currentParticipants: 0,
                participantSeeds: [],
              }]);
            }
          }
          setProgramModalOpen(false);
          setEditingProgram(null);
          setFeedback({
            open: true,
            variant: "success",
            title: wasEditingProgram ? "Program updated" : "Program added",
            description: wasEditingProgram
              ? "The program details have been updated."
              : "The program has been added to this event.",
          });
          return undefined;
        }}
        program={editingProgram}
        isBadminton={isBadminton}
      />

      <SeedingModal open={seedingOpen} onClose={() => setSeedingOpen(false)}
        eventId={eventId ?? ""} programId={seedingProgramId} />

      <ConfirmDialog
        open={deleteConfirmOpen}
        onOpenChange={setDeleteConfirmOpen}
        title="Delete Event"
        description="Delete this event permanently? This cannot be undone."
        confirmLabel="Delete Event"
        loading={saving}
        destructive
        onConfirm={handleDeleteEvent}
      />
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="font-bold text-base mb-5 pb-3"
      style={{ borderBottom: "1px solid var(--color-table-border)", color: "var(--color-heading)" }}>
      {children}
    </h2>
  );
}

function FF({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-semibold mb-2 opacity-70">{label}</label>
      {children}
      {error && <p className="text-xs mt-1" style={{ color: "var(--badge-open-text)" }}>{error}</p>}
    </div>
  );
}

function IssueList({
  title,
  issues,
  tone,
}: {
  title: string;
  issues: Array<{ row: number | null; field: string | null; message: string }>;
  tone: "error" | "warning";
}) {
  const isError = tone === "error";
  return (
    <div className="p-3 text-sm"
      style={{
        backgroundColor: isError ? "var(--badge-closed-bg)" : "var(--badge-soon-bg)",
        color: isError ? "var(--badge-closed-text)" : "var(--badge-soon-text)",
      }}>
      <p className="font-semibold mb-2">{title}</p>
      <ul className="space-y-1">
        {issues.map((issue, idx) => (
          <li key={`${issue.row ?? "file"}-${issue.field ?? "general"}-${idx}`}>
            {issue.row ? `Row ${issue.row}: ` : ""}
            {issue.field ? `${issue.field} - ` : ""}
            {issue.message}
          </li>
        ))}
      </ul>
    </div>
  );
}
